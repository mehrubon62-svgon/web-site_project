import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import {
  Cpu, Monitor, Server, MemoryStick, HardDrive, Zap, Box,
  X, Plus, Save, Upload, CheckCircle, AlertTriangle, XCircle, ShoppingCart
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useCart } from '../context/CartContext';
import { products } from '../data/products';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface SelectedComponent {
  id: string;
  name: string;
  price: number;
  image: string;
  specs: string[];
  manufacturer: string;
  power?: number;
  socket?: string;
  ramType?: string;
  formFactor?: string;
}

interface BuildSlot {
  key: string;
  label: string;
  Icon: React.ElementType;
  power: number;
}

const BUILD_SLOTS: BuildSlot[] = [
  { key: 'processor', label: 'Processor', Icon: Cpu, power: 125 },
  { key: 'gpu', label: 'Graphics Card', Icon: Monitor, power: 250 },
  { key: 'motherboard', label: 'Motherboard', Icon: Server, power: 80 },
  { key: 'ram', label: 'RAM', Icon: MemoryStick, power: 10 },
  { key: 'storage', label: 'Storage', Icon: HardDrive, power: 5 },
  { key: 'psu', label: 'Power Supply', Icon: Zap, power: 0 },
  { key: 'case', label: 'Case', Icon: Box, power: 0 },
];

const MOCK_PSU = {
  id: 'psu-1',
  name: 'Corsair RM850x',
  manufacturer: 'Corsair',
  price: 129.99,
  image: 'https://images.unsplash.com/photo-1591405351990-4726e331f141?w=400&q=80',
  specs: ['850W', '80 Plus Gold', 'Fully Modular'],
  power: 0,
};

const MOCK_CASE = {
  id: 'case-1',
  name: 'Lian Li PC-O11 Dynamic',
  manufacturer: 'Lian Li',
  price: 139.99,
  image: 'https://images.unsplash.com/photo-1738245494097-9b1e3971c3eb?w=400&q=80',
  specs: ['ATX/E-ATX', '420mm GPU Length', '360mm Radiator'],
  power: 0,
};

function ComponentModal({
  slotKey,
  onSelect,
  onClose,
  isDark,
}: {
  slotKey: string;
  onSelect: (component: SelectedComponent) => void;
  onClose: () => void;
  isDark: boolean;
}) {
  const [search, setSearch] = useState('');
  const textPrimary = isDark ? '#F9FAFB' : '#111827';
  const textSecondary = '#6B7280';
  const border = isDark ? '#374151' : '#E5E7EB';
  const cardBg = isDark ? '#374151' : '#F9FAFB';

  const available = (() => {
    let pool = products;
    if (slotKey === 'processor') pool = products.filter(p => p.category === 'Processors');
    else if (slotKey === 'gpu') pool = products.filter(p => p.category === 'GPUs');
    else if (slotKey === 'motherboard') pool = products.filter(p => p.category === 'Motherboards');
    else if (slotKey === 'ram') pool = products.filter(p => p.category === 'RAM');
    else if (slotKey === 'storage') pool = products.filter(p => p.category === 'Storage');
    else if (slotKey === 'psu') return [MOCK_PSU];
    else if (slotKey === 'case') return [MOCK_CASE];
    return pool;
  })();

  const filtered = available.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.manufacturer.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl max-h-[85vh] rounded-lg flex flex-col overflow-hidden"
        style={{ background: isDark ? '#1F2937' : '#FFFFFF', boxShadow: '0 8px 16px rgba(0,0,0,0.15)' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: border }}>
          <h2 style={{ fontSize: '20px', fontWeight: 600, color: textPrimary }}>
            Select {BUILD_SLOTS.find(s => s.key === slotKey)?.label}
          </h2>
          <button onClick={onClose} className="hover:opacity-60 transition-opacity" style={{ color: textSecondary }}>
            <X size={20} />
          </button>
        </div>

        {/* Search */}
        <div className="px-5 py-3 border-b" style={{ borderColor: border }}>
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search..."
            autoFocus
            style={{
              width: '100%',
              padding: '8px 14px',
              border: `1px solid ${border}`,
              borderRadius: '6px',
              background: isDark ? '#111827' : '#F9FAFB',
              color: textPrimary,
              fontSize: '14px',
              outline: 'none',
            }}
            onFocus={e => (e.target.style.borderColor = '#FBBF24')}
            onBlur={e => (e.target.style.borderColor = border)}
          />
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto p-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(product => (
              <div
                key={product.id}
                className="rounded-lg p-3 cursor-pointer transition-shadow hover:shadow-md"
                style={{ background: cardBg, border: `1px solid ${border}` }}
                onClick={() => onSelect({ ...product, power: 0 })}
              >
                <div className="flex gap-3">
                  <div className="w-16 h-16 rounded overflow-hidden flex-shrink-0">
                    <ImageWithFallback src={product.image} alt={product.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold mb-1 line-clamp-2" style={{ color: textPrimary }}>{product.name}</p>
                    <p className="text-xs mb-2" style={{ color: textSecondary }}>{product.specs[0]}</p>
                    <p className="text-sm font-bold" style={{ color: textPrimary }}>${product.price.toFixed(2)}</p>
                  </div>
                </div>
                <button
                  className="mt-3 w-full py-1.5 rounded text-sm font-medium transition-opacity hover:opacity-90"
                  style={{ background: '#FBBF24', color: '#111827' }}
                  onClick={e => { e.stopPropagation(); onSelect({ ...product, power: 0 }); }}
                >
                  Select
                </button>
              </div>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center py-8 text-sm" style={{ color: textSecondary }}>No components found</p>
          )}
        </div>
      </div>
    </div>
  );
}

export function ConfiguratorPage() {
  const { isDark } = useTheme();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const [build, setBuild] = useState<Record<string, SelectedComponent | null>>({
    processor: null,
    gpu: null,
    motherboard: null,
    ram: null,
    storage: null,
    psu: null,
    case: null,
  });
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [configName, setConfigName] = useState('My Gaming Build');

  const textPrimary = isDark ? '#F9FAFB' : '#111827';
  const textSecondary = '#6B7280';
  const border = isDark ? '#374151' : '#E5E7EB';
  const cardBg = isDark ? '#1F2937' : '#FFFFFF';
  const sectionBg = isDark ? '#111827' : '#FFFFFF';

  const selectComponent = (slot: string, component: SelectedComponent) => {
    setBuild(prev => ({ ...prev, [slot]: component }));
    setActiveModal(null);
  };

  const removeComponent = (slot: string) => {
    setBuild(prev => ({ ...prev, [slot]: null }));
  };

  // Calculate totals
  const totalPrice = Object.values(build).reduce((sum, c) => sum + (c?.price ?? 0), 0);
  const tax = totalPrice * 0.1;
  const grandTotal = totalPrice + tax;

  // Power calculation based on selections
  const powerMap: Record<string, number> = {
    processor: 125, gpu: 250, motherboard: 80, ram: 10, storage: 5, psu: 0, case: 0,
  };
  const totalPower = Object.entries(build).reduce((sum, [key, c]) => sum + (c ? (powerMap[key] ?? 0) : 0), 0);
  const recommendedPSU = Math.ceil(totalPower * 1.25 / 50) * 50;
  const maxPower = 700;
  const powerPercent = Math.min((totalPower / maxPower) * 100, 100);
  const powerColor = powerPercent < 60 ? '#10B981' : powerPercent < 80 ? '#F59E0B' : '#EF4444';

  // Simple compatibility check
  const filledCount = Object.values(build).filter(Boolean).length;
  const compatStatus = filledCount === 0
    ? 'empty'
    : filledCount < 5
    ? 'incomplete'
    : 'compatible';

  const handleAddToCart = () => {
    Object.values(build).forEach(component => {
      if (component) {
        addToCart({ id: component.id, name: component.name, price: component.price, image: component.image, category: 'PC Build' });
      }
    });
    navigate('/cart');
  };

  return (
    <div style={{ background: sectionBg }} className="min-h-screen">
      {activeModal && (
        <ComponentModal
          slotKey={activeModal}
          onSelect={c => selectComponent(activeModal, c)}
          onClose={() => setActiveModal(null)}
          isDark={isDark}
        />
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 style={{ fontSize: '32px', fontWeight: 700, color: textPrimary, letterSpacing: '-0.01em' }}>
              Build Your PC
            </h1>
            <p className="mt-1" style={{ color: textSecondary }}>Select components and we'll check compatibility for you</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-opacity hover:opacity-80"
              style={{ border: `1px solid #FBBF24`, color: '#FBBF24', background: 'transparent' }}
            >
              <Upload size={16} /> Load
            </button>
            <Link
              to="/configurations"
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-opacity hover:opacity-80"
              style={{ border: `1px solid #FBBF24`, color: '#FBBF24', background: 'transparent' }}
            >
              <Save size={16} /> Saved Builds
            </Link>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* LEFT: Component slots */}
          <div className="flex-1 space-y-3">
            {BUILD_SLOTS.map(slot => {
              const selected = build[slot.key];
              return (
                <div
                  key={slot.key}
                  className="rounded-lg p-4 transition-shadow"
                  style={{ background: cardBg, border: `1px solid ${border}`, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}
                >
                  {selected ? (
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded overflow-hidden flex-shrink-0">
                        <ImageWithFallback src={selected.image} alt={selected.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <slot.Icon size={14} style={{ color: '#FBBF24' }} />
                          <span className="text-xs font-medium" style={{ color: textSecondary }}>{slot.label}</span>
                        </div>
                        <p className="text-sm font-semibold truncate" style={{ color: textPrimary }}>{selected.name}</p>
                        <p className="text-xs" style={{ color: textSecondary }}>{selected.specs[0]}</p>
                      </div>
                      <div className="flex items-center gap-4 flex-shrink-0">
                        <span className="font-bold" style={{ color: textPrimary }}>${selected.price.toFixed(2)}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setActiveModal(slot.key)}
                            className="text-xs hover:opacity-70 transition-opacity"
                            style={{ color: '#FBBF24' }}
                          >
                            Change
                          </button>
                          <button
                            onClick={() => removeComponent(slot.key)}
                            className="hover:opacity-60 transition-opacity"
                            style={{ color: textSecondary }}
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <button
                      className="w-full flex items-center gap-3 group"
                      onClick={() => setActiveModal(slot.key)}
                    >
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors"
                        style={{ background: isDark ? '#374151' : '#F3F4F6' }}
                      >
                        <slot.Icon size={20} style={{ color: '#9CA3AF' }} />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-medium" style={{ color: textSecondary }}>{slot.label}</p>
                        <p className="text-xs" style={{ color: isDark ? '#6B7280' : '#9CA3AF' }}>Click to choose</p>
                      </div>
                      <div
                        className="flex items-center justify-center w-8 h-8 rounded-full transition-opacity group-hover:opacity-100 opacity-60"
                        style={{ background: '#FBBF24', color: '#111827' }}
                      >
                        <Plus size={16} />
                      </div>
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* RIGHT: Summary panel */}
          <div className="lg:w-[340px] space-y-4">
            {/* Config name */}
            <div className="rounded-lg p-4" style={{ background: cardBg, border: `1px solid ${border}` }}>
              <label className="text-xs font-medium block mb-2" style={{ color: textSecondary }}>BUILD NAME</label>
              <input
                type="text"
                value={configName}
                onChange={e => setConfigName(e.target.value)}
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  border: `1px solid ${border}`,
                  borderRadius: '6px',
                  background: isDark ? '#111827' : '#F9FAFB',
                  color: textPrimary,
                  fontSize: '14px',
                  outline: 'none',
                  fontWeight: 600,
                }}
                onFocus={e => (e.target.style.borderColor = '#FBBF24')}
                onBlur={e => (e.target.style.borderColor = border)}
              />
            </div>

            {/* Component summary */}
            <div className="rounded-lg p-4" style={{ background: cardBg, border: `1px solid ${border}` }}>
              <h3 className="text-sm font-semibold mb-3" style={{ color: textPrimary }}>Your Build</h3>
              <div className="space-y-2">
                {BUILD_SLOTS.map(slot => {
                  const c = build[slot.key];
                  return (
                    <div key={slot.key} className="flex items-center justify-between py-1.5 border-b" style={{ borderColor: border }}>
                      <div className="flex items-center gap-2 min-w-0">
                        <slot.Icon size={14} style={{ color: c ? '#FBBF24' : '#9CA3AF' }} />
                        <span className="text-xs truncate" style={{ color: c ? textPrimary : textSecondary }}>
                          {c ? c.name : `No ${slot.label}`}
                        </span>
                      </div>
                      {c ? (
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-xs font-medium" style={{ color: textPrimary }}>${c.price.toFixed(0)}</span>
                          <button onClick={() => removeComponent(slot.key)} style={{ color: '#9CA3AF' }}>
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs" style={{ color: '#9CA3AF' }}>—</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Compatibility */}
            <div className="rounded-lg p-4" style={{ background: cardBg, border: `1px solid ${border}` }}>
              <h3 className="text-sm font-semibold mb-3" style={{ color: textPrimary }}>Compatibility</h3>
              {compatStatus === 'empty' && (
                <div className="flex items-center gap-2 p-2 rounded" style={{ background: isDark ? '#374151' : '#F3F4F6' }}>
                  <CheckCircle size={16} style={{ color: '#9CA3AF' }} />
                  <span className="text-xs" style={{ color: textSecondary }}>Add components to check compatibility</span>
                </div>
              )}
              {compatStatus === 'incomplete' && (
                <div className="flex items-center gap-2 p-2 rounded" style={{ background: '#FFFBEB' }}>
                  <AlertTriangle size={16} style={{ color: '#F59E0B' }} />
                  <span className="text-xs" style={{ color: '#92400E' }}>Build incomplete — add more components</span>
                </div>
              )}
              {compatStatus === 'compatible' && (
                <div className="flex items-center gap-2 p-2 rounded" style={{ background: '#D1FAE5' }}>
                  <CheckCircle size={16} style={{ color: '#10B981' }} />
                  <span className="text-xs" style={{ color: '#065F46' }}>✓ All components compatible</span>
                </div>
              )}
            </div>

            {/* Power consumption */}
            <div className="rounded-lg p-4" style={{ background: cardBg, border: `1px solid ${border}` }}>
              <h3 className="text-sm font-semibold mb-3" style={{ color: textPrimary }}>Power Consumption</h3>
              <div className="flex items-baseline gap-1 mb-1">
                <span style={{ fontSize: '28px', fontWeight: 700, color: textPrimary }}>{totalPower}W</span>
                <span className="text-xs" style={{ color: textSecondary }}>estimated</span>
              </div>
              <p className="text-xs mb-3" style={{ color: textSecondary }}>
                Recommended PSU: <strong style={{ color: textPrimary }}>{recommendedPSU}W</strong>
              </p>
              <div className="h-1.5 rounded-full overflow-hidden" style={{ background: isDark ? '#374151' : '#E5E7EB' }}>
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${powerPercent}%`, background: powerColor }}
                />
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-xs" style={{ color: textSecondary }}>0W</span>
                <span className="text-xs" style={{ color: textSecondary }}>{maxPower}W+</span>
              </div>
            </div>

            {/* Price summary */}
            <div className="rounded-lg p-4" style={{ background: cardBg, border: `1px solid ${border}` }}>
              <h3 className="text-sm font-semibold mb-3" style={{ color: textPrimary }}>Price Summary</h3>
              <div className="space-y-1.5 mb-3">
                <div className="flex justify-between text-sm">
                  <span style={{ color: textSecondary }}>Subtotal</span>
                  <span style={{ color: textPrimary }}>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span style={{ color: textSecondary }}>Tax (10%)</span>
                  <span style={{ color: textPrimary }}>${tax.toFixed(2)}</span>
                </div>
                <div className="pt-2 border-t flex justify-between" style={{ borderColor: border }}>
                  <span className="font-semibold" style={{ color: textPrimary }}>Total</span>
                  <span style={{ fontSize: '20px', fontWeight: 700, color: textPrimary }}>${grandTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={filledCount === 0}
                className="w-full py-3 rounded-lg text-sm font-medium transition-opacity hover:opacity-90 disabled:opacity-40 flex items-center justify-center gap-2"
                style={{ background: '#FBBF24', color: '#111827' }}
              >
                <ShoppingCart size={16} />
                Add Build to Cart
              </button>
              <button
                className="w-full mt-2 py-2.5 rounded-lg text-sm font-medium transition-opacity hover:opacity-80"
                style={{ border: `1px solid #FBBF24`, color: '#FBBF24', background: 'transparent' }}
              >
                <Save size={14} className="inline mr-1.5" />
                Save Configuration
              </button>
              <button
                className="block w-full text-center mt-2 text-xs hover:opacity-70 transition-opacity"
                style={{ color: '#FBBF24' }}
              >
                Share Build
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
